This folder contains,
*  SAS Program to build SVDD model (svdd_model.sas)
*  Jupyter notebook example to build SVDD model using SWAT package (Anomaly_Detection_Air_Handling_Units_Model_Generation.ipynb)
*  Jupyter notebook example to build ESPpy project (Anomaly_Detection_Air_Handling_Units_Model_Inferencing.ipynb)